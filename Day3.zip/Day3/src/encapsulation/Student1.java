package encapsulation;

public class Student1 {
	private String name;
	private int id;
	public String branch;
}


