package encapsulation;


public class Main3getterssettersAddfunctionality {
	public static void main(String[] args) {
		
		Student3getterssettersAddfunctionality student1 = new Student3getterssettersAddfunctionality ();
		student1.setBranch ("AIML");
		student1.setId(10);
		student1.setName ("Shyamala");
	
		//calling the function
		System.out.println (student1.run ());
	}

}

