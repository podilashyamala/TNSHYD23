package encapsulation;


public class Main2getterssetters {
	
	public static void main(String[] args) {
		Student2getersseters c2= new Student2getersseters();
		c2.setBranch("AIML");
		System.out.println(c2.getBranch());
		
		
		c2.setName("Shyamala");
		System.out.println(c2.getName());
		
		
	}

}
