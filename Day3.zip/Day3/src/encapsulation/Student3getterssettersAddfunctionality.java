package encapsulation;


public class Student3getterssettersAddfunctionality {
	private String name;
	private int id;
	public String branch;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String run() {
		if(name.equals("Shyamala")&& id==10 && branch.equals("AIML")) {
          
			return "eligible to drive";
		}
         else {
        	 return "doesn't eligible for drive";
         }
		}
}