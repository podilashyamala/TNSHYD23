package encapsulation;


public class Main1 {
	public static void main(String[] args) {
		Student1 c1= new Student1();
		c1.branch="AIML";
		System.out.println(c1.branch);
	}

}