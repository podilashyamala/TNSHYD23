package oop.Task1;

public class Task1Normal {
	private int salary;
	
	public int getSalary() {
		return salary;
	}
	
	public void setSalary(int salary) {
		this.salary=salary;
		
	}
	public void printDivision() {
		if(salary>50000) {
			System.out.println("Employee belongs to Division-A");
		}else if(salary>40000) {
			System.out.println("Employee belongs to Division-B");
		}else if(salary>30000) {
			System.out.println("Employee belongs to Division-C");
		}else if(salary>20000) {
			System.out.println("Employe belongs to Division-D");
		}
		
	}

}
