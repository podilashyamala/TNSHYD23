package oop.Task1;

public class Task1Main {
	
	public static void main(String args[]) {
		Task1Normal n1=new Task1Normal();
		
		n1.setSalary(52000);
		n1.printDivision();
		
		n1.setSalary(44000);
		n1.printDivision();
		
		n1.setSalary(35000);
		n1.printDivision();
		
		n1.setSalary(27000);
		n1.printDivision();
		
	}

}
