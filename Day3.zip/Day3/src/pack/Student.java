package pack;
	public class Student {
		int b=30;
	    static int c=40;
	public static void main(String args[]) {
		int a=20;
		System.out.println(a);
		Student student1=new Student();
		System.out.println(student1.b);
		System.out.println(Student.c);
		
				
	}

	}


