package variables2;

class Student2{
	int b=30;
    static int c=40;
}
 class Student1 {
	  
 public static void main(String[] args) {
	 
		  
	 int a=20;
	 System.out.println(a);
     Student2 student=new Student2();
	 System.out.println(student.b);
	 System.out.println(Student2.c);
		
		
		
		
	}
	
	
}
 