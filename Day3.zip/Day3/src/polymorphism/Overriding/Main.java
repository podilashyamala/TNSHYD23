package polymorphism.Overriding;

class Parent {
	 void display() {
		System.out.println("Parent's display()"); 
	}
}
class Child extends Parent{
	 void display() {
		 System.out.println("Child's display()");
	  }
}
public class Main{
	public static void main(String[] args) {
		
		
		Parent obj1 = new Parent();
		obj1.display();
		Parent obj2 = new Child();
		obj2.display();
		
 }
}
