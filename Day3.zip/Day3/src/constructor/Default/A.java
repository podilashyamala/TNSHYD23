package constructor.Default;

public class A {
	String department;
	public A() {
		System.out.println("Constructor called");
		department="AIML";
		
	}
	


public static void main(String args[]) {
	A obj=new A();
	System.out.println("Department name is"+obj.department);
	
	
	
}
	
}
