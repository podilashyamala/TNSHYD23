package constructor.overloading;

public class MyClass {
	int num1;
	double num2;
	public MyClass() {
		System.out.println("Default Constructor called");
		num1=1;
		num2=1.5;
		
	}
	public MyClass(int x) {
		System.out.println("parameterized constructor called");
		num1=x;
		
	}
	public MyClass(int x,double z) {
		System.out.println("Parameterized constructor2 called");
		num1=x;
		num2=z;
		
		
	}
	void displayData() {
		System.out.println("Num1:"+num1+"\n Num2:"+num2);
		
	}
	public static void main(String args[]) {
		MyClass obj1=new MyClass();
		obj1.displayData();
		MyClass obj2=new MyClass();
		obj2.displayData();
		MyClass obj3=new MyClass();
		obj3.displayData();
	}

}
