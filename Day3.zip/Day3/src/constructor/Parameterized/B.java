package constructor.Parameterized;

public class B {
	String department;
	public B(String x) {
		System.out.println("Constructor called");
		department=x;
			
	}

public static void main(String args[]) {
	B obj=new B("AIML");
	System.out.println("Department name is"+obj.department);
}
}