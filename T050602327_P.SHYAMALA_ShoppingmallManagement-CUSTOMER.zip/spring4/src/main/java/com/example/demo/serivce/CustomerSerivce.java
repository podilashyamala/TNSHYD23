package com.example.demo.serivce;

import java.util.List;

import com.example.demo.entity.Customer;

public interface CustomerSerivce {

	Customer saveCustomer(Customer customer);

	List<Customer> fetchCustomer();

	Customer fetchCustomerById(Long id);

	void deleteCustomerById(Long id);


}
